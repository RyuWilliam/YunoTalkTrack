package co.yuno.n8nService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class N8nServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(N8nServiceApplication.class, args);
	}

}
