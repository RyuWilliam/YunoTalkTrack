package co.yuno.n8nService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class N8nServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
